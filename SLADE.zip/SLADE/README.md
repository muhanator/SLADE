# SLADE
SLADE is the 1 stop schedule maker allowing you to schedule and do everything you want in a day exactly as you want it


SOME BASIC GIT RULES (I recommend that you download Git Bash):

To Clone this repo:
1) click on the "clone or download" button and copy the link
2) go into the workspace that you want to work in eg: Desktop/project/personal
3) type 'git clone <INSERT LINK>' and voila!

When working on an issue:
* NO ONE WILL WORK ON MASTER OR COMMIT DIRECTLY TO MASTER
- You will be assigned issues or you will assign yourself issues that you want to work on 
1) If you are working on "TASK-20": Then follow the commands:

$ git checkout -b TASK-20-Description-about-your-task master

2) when making and committing changes:

$ git status (shows you what changes you have made)

$ git add . (adds all the files you modified)

$ git commit -m "TASK-20: Write a description about the change you made"

$git push (to push your local changes to github)


3) Making a PR
- After you have committed a change, you have to go onto Github and create a Pull Request and assign someone to review the PR for you
- Once they have reviewed and approved your changes, you can merge to master


TEAM MEMBERS:

- Muhammad Saad Mujtaba, @muhanator# SLADE
- Michael Lee, @mlee97
- Jeremy Davis, @jeremy-davis-mcgill
- Armando Mancino, @mandocino


SLADE is the 1 stop schedule maker allowing you to shedule and do everything you want in a day exactly as you want it
